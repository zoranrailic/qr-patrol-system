<?php

namespace App\Models;

use App\Models\Base\PermissionUser as BasePermissionUser;

class PermissionUser extends BasePermissionUser
{

}

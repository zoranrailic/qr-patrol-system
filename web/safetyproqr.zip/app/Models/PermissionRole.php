<?php

namespace App\Models;

use App\Models\Base\PermissionRole as BasePermissionRole;

class PermissionRole extends BasePermissionRole
{

}

<!-- page title -->
<?php $__env->startSection('title', 'Create and Update Users ' . Config::get('adminlte.title')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Users</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Add or Update</h3>
        </div>

        <?php echo e(html()->form('POST', route($data->form_action))->attribute('autocomplete', 'off')->acceptsFiles()->open()); ?>

        <?php echo e(html()->hidden('id', $data->id)->id('user_id')); ?>


        <div class="card-body">
            <div class="form-group row">
                <div class="col-sm-2 col-form-label">
                    <strong class="field-title">Name</strong>
                </div>
                <div class="col-sm-10 col-content">
                    <?php echo e(html()->text('name', $data->name)->class('form-control')->required()); ?>

                    <small class="form-text text-muted">
                        <i class="fa fa-question-circle" aria-hidden="true"></i> User name.
                    </small>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-2 col-form-label">
                    <strong class="field-title">Email</strong>
                </div>
                <div class="col-sm-10 col-content">
                    <?php echo e(html()->email('email', $data->email)->class('form-control')->required()); ?>

                    <small class="form-text text-muted">
                        <i class="fa fa-question-circle" aria-hidden="true"></i> User email, this email for login.
                    </small>
                </div>
            </div>

            <div id="form-password" class="form-group row">
                <div class="col-sm-2 col-form-label">
                    <strong class="field-title">Password</strong>
                </div>
                <div class="col-sm-10 col-content">
                    <?php echo e(html()->password('password')->id('password')->class('form-control')->attribute('autocomplete', 'new-password')); ?>

                    <?php if($data->page_type === 'edit'): ?>
                        <small id="passwordHelpBlock" class="form-text text-muted">
                            <i class="fa fa-question-circle" aria-hidden="true"></i> Leave it blank if you don't want to change
                        </small>
                    <?php else: ?>
                        <small class="form-text text-muted">
                            <i class="fa fa-question-circle" aria-hidden="true"></i> User password, this password for login.
                        </small>
                    <?php endif; ?>
                    <label class="reset-field-password" for="show-password"><input id="show-password" type="checkbox" name="show-password" value="1"> Show Password</label>
                </div>
            </div>

            
            <div id="form-image" class="form-group row">
                <div class="col-sm-2 col-form-label">
                    <strong class="field-title">Image</strong>
                </div>
                <div class="col-sm-10 col-content">
                    <?php echo e(html()->file('image')->class('custom-file-input')->accept('image/gif, image/jpeg,image/jpg,image/png')->attribute('data-max-width', '800')->attribute('data-max-height', '400')); ?>

                    <label class="custom-file-label" for="customFile">Choose file</label>
                    <span class="image-upload-label"><i class="fa fa-question-circle" aria-hidden="true"></i> Please upload the image (Recommended size: 160px × 160px, max 5MB)</span>
                    <div class="image-preview-area">
                        <div id="image_preview" class="image-preview">
                            <?php if($data->page_type == 'edit'): ?>
                                <img src="<?php echo e(asset('uploads/'.$data->image)); ?>" width="160" title="image" class="img-circle elevation-2">
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/default-user.png')); ?>" width="160" title="image" class="img-circle elevation-2">
                            <?php endif; ?>
                        </div>
                        
                        <p class="delete-image-preview <?php if($data->image != null && $data->image != 'default-user.png'): ?> show <?php endif; ?>" onclick="deleteImagePreview(this);"><i class="fa fa-window-close"></i></p>
                        
                        <?php echo e(html()->hidden('image_delete')); ?>

                    </div>
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-2 col-form-label">
                    <strong class="field-title">Role</strong>
                </div>
                <div class="col-sm-10 col-content">
                    <?php echo e(html()->select('role', $role, $data->role)->id('role')->class('form-control')->required()); ?>

                    <small class="form-text text-muted">
                        <i class="fa fa-question-circle" aria-hidden="true"></i> User role.
                    </small>
                    <?php if($data->page_type == 'add'): ?>
                    <small class="form-text text-muted hide text-role">
                        <i class="fa fa-question-circle " aria-hidden="true"></i> We will also create the QR code. Access the QR from "History QR"
                    </small>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($data->role == 2 || $data->role == 3): ?>
                <?php echo e(html()->hidden('qr_id', $data->qr_id)); ?>

            <?php endif; ?>

        </div>

        <div class="card-footer">
            <div id="form-button">
                <div class="col-sm-12 text-center top20">
                    <?php echo e(html()->button($data->button_text)->type('submit')->name('submit')->id('btn-admin-member-submit')->class('btn btn-primary')); ?>

                </div>
            </div>
        </div>
        <?php echo e(html()->form()->close()); ?>

    </div>

    <!-- /.card -->
    </div>
    <!-- /.row -->
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>var typePage = "<?php echo e($data->page_type); ?>";</script>
    <script src="<?php echo e(asset('js/backend/users/form.js'). '?v=' . rand(99999,999999)); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vafgroup/pretor.development.in.rs/resources/views/backend/users/form.blade.php ENDPATH**/ ?>
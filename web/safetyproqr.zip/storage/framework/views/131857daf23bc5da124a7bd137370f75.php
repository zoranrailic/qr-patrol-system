<!-- page title -->
<?php $__env->startSection('title', 'Create and Update Histories Qr ' . Config::get('adminlte.title')); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Histories Qr</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Add or Update</h3>
    </div>

    <?php echo e(html()->form('POST')->route($data->form_action)->open()); ?>

    <?php echo e(html()->hidden('id', $data->id, array('id' => 'id'))); ?>


    <div class="card-body">

        <div class="form-group row">
            <div class="col-sm-2 col-form-label">
                <strong class="field-title">Name</strong>
            </div>
            <div class="col-sm-10 col-content">
                <?php echo e(html()->text('name', $data->name)->required()->class('form-control')); ?>

                <small class="form-text text-muted">
                    <i class="fa fa-question-circle" aria-hidden="true"></i> Name of empoyer or student.
                </small>
            </div>
        </div>

    </div>

    <div class="card-footer">
        <div id="form-button">
            <div class="col-sm-12 text-center top20">
                <button type="submit" name="submit" id="btn-admin-member-submit" class="btn btn-primary"><?php echo e($data->button_text); ?></button>
            </div>
        </div>
    </div>
    <?php echo e(html()->form()->close()); ?>

</div>

<!-- /.card -->
</div>
<!-- /.row -->
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    var typePage = "<?php echo e($data->page_type); ?>";
</script>

<script src="<?php echo e(asset('js/backend/histories/form.js'). '?v=' . rand(99999,999999)); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vafgroup/pretor.development.in.rs/resources/views/backend/histories/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'History Qr  | ' . Config::get('adminlte.title')); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>History Qr</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">List</h3>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <?php echo $html->table(['class' => 'table table-hover']); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('vendor/datatables/css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/datatables-plugins/buttons/css/buttons.bootstrap4.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!--Data tables-->
    <script src="<?php echo e(asset('vendor/datatables/buttons.server-side.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/jszip/jszip.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/pdfmake/pdfmake.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/pdfmake/vfs_fonts.js')); ?>"></script>
    
    <script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/dataTables.buttons.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.colVis.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.html5.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/buttons/js/buttons.print.js')); ?>"></script>
    <?php echo $html->scripts(); ?>

    <script src="<?php echo e(asset('js/main_index.js'). '?v=' . rand(99999,999999)); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vafgroup/pretor.development.in.rs/resources/views/backend/histories/index.blade.php ENDPATH**/ ?>
function generateNewKey(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

$('.select2').select2();

$(document).on('click', '#generate-key', function (e) {
    e.preventDefault();
    $('#key').val(generateNewKey(40))
});
